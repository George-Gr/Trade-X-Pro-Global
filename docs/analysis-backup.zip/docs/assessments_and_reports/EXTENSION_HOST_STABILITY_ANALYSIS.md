# Extension Host Stability Analysis & Recovery Plan

**Date:** November 30, 2025  
**Status:** Critical Issues Identified  
**Severity:** HIGH - Extension host crashes every 5-10 minutes  

---

## Executive Summary

The VS Code extension host is experiencing **cascading failures** due to **navigator polyfill migration issues**, **lock file contention**, **extension compatibility problems**, and **network timeouts**. These issues cause the remote extension host to crash and restart repeatedly, degrading developer productivity.

### Key Metrics
- **Crash Frequency:** ~1 crash per 5-10 minutes (see timestamps in logs)
- **Recovery Time:** ~15-30 seconds per restart
- **Root Causes Identified:** 5 critical, 4 high-priority
- **Impact:** Copilot Chat unavailable, terminal integration broken, Git operations delayed

---

## Root Cause Analysis

### 1. **CRITICAL: PendingMigrationError - Navigator Polyfill (HIGH IMPACT)**

**Symptom:**
```
PendingMigrationError: navigator is now a global in nodejs
```

**Affected Extensions:**
- `github.codespaces` (v1.18.3)
- `github.copilot-chat` (v0.33.3)
- All dependencies: `axios`, `@octokit/*`, `universal-user-agent`

**Root Cause:**
Node.js 20+ made `navigator` a global object. Extensions using web libraries (built for browser environments) that shim their own `navigator` object are now conflicting with Node.js globals. This creates a namespace collision.

**Why It Crashes:**
Multiple extensions try to access/modify `navigator` simultaneously:
1. `axios` tries to access `navigator.userAgent`
2. `@octokit/graphql` tries to call `getUserAgent()`
3. `universal-user-agent` tries to check `navigator` existence
4. Each attempt throws because the property is already defined globally
5. Extensions fail to initialize → extension host crashes

**Stack Trace Pattern:**
```
at get (file:///vscode/.../extensionHostProcess.js:402:6611)  ← Property access fails
at Object.33559 (/home/node/.vscode-remote/extensions/node_modules/axios/dist/node/axios.cjs:1363:20)
at __webpack_require__ (/home/node/.vscode-remote/extensions/github.codespaces-1.18.3/webpack/bootstrap:19:32)
```

**Frequency:** Occurs 7+ times during extension initialization (11:39:31-11:39:33)

---

### 2. **CRITICAL: Lock File Contention & Stale Locks**

**Symptom:**
```
Error: EEXIST: file already exists, open '/home/node/.vscode-remote/data/User/workspaceStorage/33244c5f/vscode.lock'
Lock '.../vscode.lock': Could not acquire lock, checking if the file is stale.
Lock '.../vscode.lock': The lock does not look stale, elapsed: 516777 ms, giving up.
```

**Root Cause:**
Multiple processes trying to access the same workspace simultaneously:
1. Old VS Code session still holding lock (516+ seconds elapsed = 8+ minutes old)
2. New session cannot acquire lock
3. Workspace storage becomes inaccessible
4. Extensions fail to initialize settings/state

**Why It Cascades:**
- Extensions depend on workspace storage for configuration
- Without access, they fail to load
- Failed extensions → extension host restart
- Restart tries to acquire same lock → same failure
- **Infinite crash loop**

**Evidence:**
```
11:39:28.452 - Cannot acquire lock (33244c5f)
11:39:28.524 - Cannot acquire lock (33244c5f-1) but succeeds on stale lock detection
→ One workspace storage unavailable, partial initialization
```

---

### 3. **CRITICAL: Network Connectivity Issues & MCP Timeout**

**Symptom (Window Output Log):**
```
[error] [Network] #3: https://api.mcp.github.com/v0.1/servers/... - error GET Failed to fetch
[error] [Network] #20: https://ms-vscode-remote.gallerycdn.azure.cn/... - error GET Failed to fetch
[error] [Network] #21: https://dbaeumer.gallerycdn.azure.cn/... - error GET Failed to fetch
```

**Root Causes:**
1. **MCP Server Unavailable:** `context7-mcp` cannot reach GitHub API (CDN timeout)
2. **Extension Gallery CDN Blocked:** Azure CDN and Gallerycdn not reachable (network/firewall)
3. **External Service Dependencies:** Extension host tries to load extensions from remote CDNs
4. **No Fallback:** When CDN fails, extension loading hangs

**Why It Causes Crashes:**
- Extension initialization waits for MCP context7 to respond
- CDN timeout causes extension load timeout
- Timeout threshold exceeded → extension host forced restart
- Restart re-attempts same failed requests

**Network Errors Observed:**
```
Failed to fetch from:
- api.mcp.github.com (MCP servers list)
- ms-vscode-remote.gallerycdn.azure.cn (remote containers extension)
- dbaeumer.gallerycdn.azure.cn (ESLint extension)
```

---

### 4. **HIGH: Missing/Invalid Chat Participant Registration**

**Symptom:**
```
[error] Error: chatParticipant must be declared in package.json: claude-code
[error] Error: Unknown agent: "copilot-swe-agent"
[warning] No extension contribution found for chat session type: copilot-cloud-agent
```

**Root Cause:**
- Extensions registered agents/chat participants not declared in `package.json`
- `claude-code` participant not in any extension manifest
- `copilot-swe-agent` references non-existent agent
- Configuration mismatch between extension code and manifest

**Why It Matters:**
- Extensions fail to initialize chat features
- Copilot Chat extension hangs during activation
- Error occurs during critical extension initialization phase

---

### 5. **HIGH: Socket Timeouts & Connection Resets**

**Symptom (Window Output Log):**
```
[info] received socket timeout event (unacknowledgedMsgCount: 1, timeSinceOldestUnacknowledgedMsg: 20004)
[info] starting reconnecting loop
[info] Extension host (Remote) is unresponsive
[info] Extension host (Remote) is responsive (after 15+ seconds)
```

**Pattern:**
```
17:43:25 - unresponsive
17:43:27 - responsive (+2s)
17:49:02 - unresponsive
17:49:02 - responsive (+0.1s)
17:49:07 - unresponsive
17:50:02 - responsive (+55s)  ← LONG RECOVERY
...repeats every 5-10 minutes
```

**Root Causes:**
1. **Extension host blocked on I/O:** Network requests to CDN/MCP timeout
2. **Message acknowledgment timeout:** 20+ second window without ACK
3. **Socket closure:** WSS connection drops during timeout
4. **Full reconnect cycle:** Must re-establish all sockets (Management + ExtensionHost)
5. **Cascading failures:** One timeout triggers full infrastructure restart

---

### 6. **MEDIUM: Rate Limiting & Upstream Errors**

**Symptom:**
```
[error] ChatRateLimited: Rate limit exceeded
{"message":"Provider returned error","code":429,"metadata":{"raw":"qwen/qwen3-coder:free is temporarily rate-limited upstream..."}}
```

**Impact:** Chat provider exhausted free tier limits, causing chat requests to fail

---

### 7. **MEDIUM: Deprecation Warnings & Node Compatibility**

**Symptom:**
```
[warning] [Extension Host] (node:273) [DEP0040] DeprecationWarning: The `punycode` module is deprecated
[warning] [Extension Host] ExperimentalWarning: SQLite is an experimental feature
```

**Root Cause:**
- Extensions use deprecated Node APIs
- SQLite experimental feature causing instability
- These don't crash but indicate version compatibility issues

---

## Crash Timeline Pattern

```
Extension Host Lifecycle:
11:39:28 - START (lock contention detected)
11:39:28-31 - Navigator errors cascade (7 PendingMigrationErrors)
11:39:33 - Chat participant registration fails (chatParticipant error)
11:39:43 - Unknown agent registration fails (copilot-swe-agent)
~17:43-17:51 - Socket timeout cycle begins (every 5-10 minutes)
18:02:24 - Rate limit hit (API exhausted)
18:04:12+ - Full socket reconnection cycle (socket timeout + reconnect)
```

**Total Issue Duration:** 8+ hours with continuous crashes

---

## Impact Assessment

| Impact | Severity | Affected Features |
|--------|----------|------------------|
| **Copilot Chat Unavailable** | CRITICAL | Code completion, inline suggestions, chat interface |
| **Terminal Integration Broken** | CRITICAL | `github.copilot.chat.agent.terminal.*` features |
| **Extension Host Restarts** | CRITICAL | All extensions reload every 5-10 min (15-30s downtime) |
| **Dev Server Inaccessible** | HIGH | Port forwarding delays, npm commands hang |
| **Git Operations Delayed** | HIGH | GitHub PR features, Git integration slow |
| **Network Requests Fail** | HIGH | MCP context7, extension gallery downloads |
| **Settings/Configuration Lost** | HIGH | Extension state not persisted (lock file issue) |
| **Debugging/Error Tracking Broken** | MEDIUM | Sentry, console logging unreliable |

---

## Solution Strategy

### Phase 1: Immediate Stabilization (Quick Wins - 30 mins)
Fix configuration issues that prevent extension host from initializing

### Phase 2: Deep Fixes (Root Causes - 1-2 hours)
Address navigator polyfill, lock file, network issues

### Phase 3: Long-term Hardening (Resilience - Ongoing)
Add monitoring, graceful degradation, fallback mechanisms

---

## Next Section: Implementation Plan

See `EXTENSION_HOST_RECOVERY_PLAN.md` for detailed fixes.
