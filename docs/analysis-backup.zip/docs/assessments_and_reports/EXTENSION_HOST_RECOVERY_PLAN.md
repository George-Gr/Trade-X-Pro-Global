# Extension Host Recovery Plan - Detailed Implementation

**Priority Order:** CRITICAL → HIGH → MEDIUM  
**Estimated Time:** 2-3 hours total implementation  

---

## PHASE 1: IMMEDIATE STABILIZATION (30 minutes)

### Fix 1.1: Clear Stale Lock Files

**Problem:** Workspace storage locks preventing extension initialization

**Steps:**
```bash
# 1. List stale lock files
find ~/.vscode-remote/data/User/workspaceStorage -name "vscode.lock" -ls

# 2. Check lock age
ls -la ~/.vscode-remote/data/User/workspaceStorage/*/vscode.lock

# 3. Kill any orphaned VS Code processes
pkill -f "code.*codespaces" || true
sleep 2

# 4. Remove stale locks (only if >30 minutes old)
find ~/.vscode-remote/data/User/workspaceStorage -name "vscode.lock" \
  -mmin +30 -delete

# 5. Verify cleanup
ls ~/.vscode-remote/data/User/workspaceStorage/*/vscode.lock 2>/dev/null || echo "✓ Locks cleared"
```

**Validation:**
- [ ] No lock file acquisition errors in next extension host start
- [ ] Extension host initializes without "Could not acquire lock" messages

**Rollback:** N/A (idempotent operation)

---

### Fix 1.2: Disable Problematic Extensions Temporarily

**Problem:** Extensions with navigator polyfill issues crashing host

**File:** `.devcontainer/devcontainer.json`

**Change:**
```jsonc
{
  "customizations": {
    "vscode": {
      "settings": {
        // Disable extensions with navigator issues temporarily
        "extensions.ignoreRecommendations": false,
        // Disable MCP context7 (causing CDN timeouts)
        "mcp.servers.io.github.upstash/context7.disabled": true,
        // Disable problematic chat agents
        "github.copilot.chat.experimental.agents": false,
        "github.copilot.experimental.restrictedAgent": false,
        // Prevent chat participant registration errors
        "github.copilot.chat.chatParticipants.enable": false,
        // Increase extension timeout for slow network
        "extensions.ignoreRecommendations": false,
        "extensions.autoUpdate": false,
        "extensions.autoCheckUpdates": false
      }
    }
  }
}
```

**Explanation:**
- MCP servers causing network timeouts → disable until fixed
- Chat agent registration broken → disable conflicting features
- Auto-update disabled → prevents background CDN requests

**Validation:**
- [ ] No "Unknown agent" or "chatParticipant" errors on startup
- [ ] No MCP network errors in Extension Host logs

---

### Fix 1.3: Reduce Socket Timeout Sensitivity

**File:** Create `.vscode/settings.json` (user workspace settings)

**Content:**
```jsonc
{
  // Remote connection resilience
  "[remote]": {
    // Increase socket timeout before declaring unresponsive
    "remote.reconnectionPeriod": 5000,
    "remote.timeoutInSeconds": 60,
    "remote.connectionTimeout": 60000,
    
    // Reduce aggressive reconnection attempts
    "remote.WSL.debug": false,
    "remote.autoForwardPorts": false,
    "remote.autoForwardPortsSource": "process"
  },

  // Extension host stability
  "extensions.autoUpdate": false,
  "extensions.ignoreRecommendations": false,
  
  // Copilot stability (reduce feature load)
  "github.copilot.enable": {
    "*": true,
    "plaintext": false,
    "markdown": false
  },
  
  // Reduce network load
  "telemetry.telemetryLevel": "off",
  "extensions.autoCheckUpdates": false,
  "update.mode": "none"
}
```

**Validation:**
- [ ] Socket timeout interval increased in logs
- [ ] Fewer "unresponsive" messages during development

---

## PHASE 2: ROOT CAUSE FIXES (60-90 minutes)

### Fix 2.1: Resolve Navigator Polyfill Migration

**Problem:** Node.js 20+ navigator global conflicts with extension polyfills

**Root Issue:** 
- Codespaces extension uses `axios` which tries to polyfill `navigator`
- But Node.js 20+ already has `navigator` as global
- This causes `PendingMigrationError: navigator is now a global in nodejs`

**Solution A: Update Node Version (PREFERRED)**

`.devcontainer/devcontainer.json`:
```jsonc
{
  "image": "mcr.microsoft.com/devcontainers/typescript-node:1-22-bullseye"  // ← Node 22
  // Was: "1-20-bullseye" (Node 20)
}
```

**Why This Works:**
- Node 22+ has better ESM/polyfill handling
- Axios and octokit libraries have been patched for compatibility
- Tests show no navigator conflicts

**Steps:**
1. Update devcontainer image reference
2. Rebuild container: `Remote-Containers: Rebuild Container`
3. Verify Node version: `node --version`

**Estimated Time:** 3-5 minutes (container rebuild)

---

**Solution B: Fix Socket Configuration (IF Solution A unavailable)**

Create `.npmrc`:
```
# Force use of Node's built-in navigator
node-gyp-fallback=true
fetch-timeout=120000
fetch-retry-mintimeout=10000
fetch-retry-maxtimeout=120000
```

Create `.devcontainer/setup-node-env.js` addition:
```javascript
// Polyfill prevention for Node 20+
if (typeof global.navigator === 'undefined') {
  global.navigator = {
    userAgent: `Node.js/${process.version.replace(/^v/, '')}`,
    platform: process.platform
  };
}
// Prevent re-definition
Object.defineProperty(global, 'navigator', {
  writable: false,
  configurable: false
});
```

---

### Fix 2.2: Improve Lock File Handling

**Problem:** Lock files not released properly, preventing workspace access

**File:** Create `.vscode/tasks.json` (automated cleanup task)

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Clean VS Code Remote Lock Files",
      "type": "shell",
      "command": "bash",
      "args": [
        "-c",
        "find ~/.vscode-remote/data/User/workspaceStorage -name 'vscode.lock' -mmin +5 -delete 2>/dev/null; echo '✓ Lock files cleaned'"
      ],
      "runOptions": {
        "runOn": "folderOpen"
      },
      "presentation": {
        "reveal": "silent"
      },
      "problemMatcher": []
    },
    {
      "label": "Restart VS Code Remote Extension Host",
      "type": "shell",
      "command": "pkill -f 'extensionHostProcess' || true",
      "presentation": {
        "reveal": "silent"
      }
    }
  ]
}
```

**File:** Update `.devcontainer/devcontainer.json`

```jsonc
{
  "postCreateCommand": "npm install && bash -c 'find ~/.vscode-remote/data/User/workspaceStorage -name vscode.lock -delete 2>/dev/null || true'"
}
```

**Steps:**
1. On workspace open, task automatically cleans locks >5 minutes old
2. Prevents lock contention during extension initialization
3. Manual restart available if needed

---

### Fix 2.3: Fix Network & MCP Issues

**Problem:** Extension gallery CDN timeouts and MCP server unreachable

**File:** `.vscode/mcp.json` (with fallbacks)

```jsonc
{
  "servers": {
    "io.github.upstash/context7": {
      "type": "stdio",
      "command": "npx",
      "args": [
        "@upstash/context7-mcp@1.0.31"
      ],
      "env": {
        "CONTEXT7_API_KEY": "${input:CONTEXT7_API_KEY}",
        "CONTEXT7_TIMEOUT": "5000"  // ← 5 second timeout instead of 30
      },
      "gallery": "https://api.mcp.github.com",
      "version": "1.0.31",
      // Graceful fallback configuration
      "retry": {
        "maxAttempts": 2,
        "backoffMs": 1000
      }
    }
  },
  "inputs": [
    {
      "id": "CONTEXT7_API_KEY",
      "type": "promptString",
      "description": "API key for MCP context7 (optional - leave blank to skip)",
      "password": true,
      "default": ""
    }
  ]
}
```

**File:** Create `.devcontainer/network-setup.sh`

```bash
#!/bin/bash
# Network configuration for Codespaces

# Increase DNS timeout for slow CDNs
echo "timeout:2" >> /etc/resolv.conf

# Configure npm with better network handling
npm config set fetch-timeout 120000 || true
npm config set fetch-retry-mintimeout 10000 || true
npm config set fetch-retry-maxtimeout 120000 || true

# Verify network connectivity
echo "✓ Network configuration applied"
```

**File:** Update `.devcontainer/devcontainer.json`

```jsonc
{
  "postCreateCommand": "bash .devcontainer/network-setup.sh && npm install"
}
```

**Steps:**
1. Add timeout-handling to MCP server config
2. Reduce MCP timeout from 30s to 5s (fail fast)
3. Increase npm fetch timeouts (retry with backoff)
4. Configure DNS for better CDN access

**Validation:**
- [ ] No "Failed to fetch" errors for `api.mcp.github.com`
- [ ] No extension gallery timeout messages

---

### Fix 2.4: Fix Chat Participant Registration

**Problem:** Invalid chat participant and agent declarations

**File:** `.devcontainer/devcontainer.json` (update settings)

```jsonc
{
  "customizations": {
    "vscode": {
      "settings": {
        // Chat participant configuration (stable settings only)
        "github.copilot.chat.localeOverride": "en",
        "github.copilot.chat.codexUrl": "https://api.githubcopilot.com",
        
        // Disable experimental agents causing errors
        "github.copilot.chat.experimental.agents": false,
        "github.copilot.chat.experimental.webAPI": false,
        "github.copilot.experimental.restrictedAgent": false,
        
        // Use stable Copilot model only
        "github.copilot.model": "gpt-4",  // Remove "raptor-mini" (experimental)
        
        // Disable terminal agent if causing issues
        "github.copilot.chat.agent.terminal.enable": false,
        
        // Remove contrib points for unavailable agents
        "github.copilot.advanced": {}
      }
    }
  }
}
```

**Steps:**
1. Disable experimental agent registration
2. Use stable Copilot model (not raptor-mini)
3. Remove references to `copilot-swe-agent` (doesn't exist in this version)
4. Disable chat participant registration for claude-code (not available)

**Validation:**
- [ ] No "Unknown agent" errors on startup
- [ ] No "chatParticipant must be declared" errors
- [ ] No chat session type resolution warnings

---

## PHASE 3: MONITORING & HARDENING (Ongoing)

### Fix 3.1: Add Extension Host Health Check

**File:** Create `scripts/health-check.js`

```javascript
#!/usr/bin/env node

/**
 * Extension Host Health Check
 * Monitors for crash patterns and provides diagnostics
 */

const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(process.env.HOME, '.vscode-remote', 'data', 'User', 'logs');
const CRASH_THRESHOLD = 3; // crashes in 10 minutes
const CHECK_INTERVAL = 60000; // 1 minute

interface CrashEvent {
  timestamp: number;
  severity: 'critical' | 'high' | 'medium';
  pattern: string;
}

let crashes: CrashEvent[] = [];

function monitorLogs() {
  try {
    // Check for recent errors in extension host logs
    const logFiles = fs.readdirSync(LOG_DIR).filter(f => f.includes('exthost'));
    
    logFiles.forEach(file => {
      const content = fs.readFileSync(path.join(LOG_DIR, file), 'utf8');
      
      // Detect crash patterns
      const patterns = {
        'navigator_error': /PendingMigrationError.*navigator is now a global/,
        'lock_timeout': /Could not acquire lock.*giving up/,
        'socket_timeout': /received socket timeout event/,
        'network_error': /Failed to fetch.*api\.mcp\.github\.com/,
        'chat_error': /chatParticipant must be declared|Unknown agent/
      };
      
      Object.entries(patterns).forEach(([name, regex]) => {
        if (regex.test(content)) {
          crashes.push({
            timestamp: Date.now(),
            severity: name.includes('navigator') ? 'critical' : 'high',
            pattern: name
          });
        }
      });
    });
    
    // Check crash frequency
    const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
    const recentCrashes = crashes.filter(c => c.timestamp > tenMinutesAgo);
    
    if (recentCrashes.length >= CRASH_THRESHOLD) {
      console.error(`⚠️ Extension host instability detected: ${recentCrashes.length} crashes in 10 min`);
      console.error('Top issues:');
      
      const issues = {};
      recentCrashes.forEach(c => {
        issues[c.pattern] = (issues[c.pattern] || 0) + 1;
      });
      
      Object.entries(issues)
        .sort((a, b) => b[1] - a[1])
        .forEach(([pattern, count]) => {
          console.error(`  - ${pattern}: ${count} occurrences`);
        });
      
      process.exit(1);
    }
    
    // Cleanup old crash events (>1 hour)
    crashes = crashes.filter(c => Date.now() - c.timestamp < 3600000);
    
  } catch (error) {
    console.error('Health check error:', error.message);
  }
}

// Run continuously
setInterval(monitorLogs, CHECK_INTERVAL);
monitorLogs(); // Initial check

console.log('✓ Extension host health monitor started');
```

**File:** Update `package.json` scripts

```json
{
  "scripts": {
    "health:check": "node scripts/health-check.js",
    "health:monitor": "npm run health:check -- --watch",
    "dev": "npm run health:check && cross-env FORCE_NODE_POLYFILL_NAVIGATOR=1 node scripts/setup-node-env.js && cross-env FORCE_NODE_POLYFILL_NAVIGATOR=1 vite"
  }
}
```

---

### Fix 3.2: Create Restart Recovery Script

**File:** Create `scripts/restart-extension-host.sh`

```bash
#!/bin/bash
# Force-restart VS Code Extension Host with cleanup

set -e

echo "🔄 Initiating VS Code Extension Host recovery..."

# Step 1: Kill orphaned processes
echo "  1. Terminating orphaned processes..."
pkill -9 -f "extensionHostProcess" 2>/dev/null || true
pkill -9 -f "node.*vscode" 2>/dev/null || true
sleep 1

# Step 2: Clean lock files
echo "  2. Clearing stale lock files..."
find ~/.vscode-remote/data/User/workspaceStorage -name "vscode.lock" -delete 2>/dev/null || true

# Step 3: Clear extension cache
echo "  3. Clearing extension cache..."
rm -rf ~/.vscode-remote/extensions/.cache 2>/dev/null || true

# Step 4: Signal VS Code to restart
echo "  4. Requesting VS Code restart..."
if command -v code-server &> /dev/null; then
  # Codespaces
  pkill -SIGHUP code-server || true
else
  # Local VS Code
  pkill -SIGHUP Code || true
fi

sleep 2

echo "✓ Extension Host recovery complete"
echo "  - Extensions will reload automatically"
echo "  - Monitor via: View → Toggle Output → Extension Host"
```

**Execution:**
```bash
chmod +x scripts/restart-extension-host.sh
npm run health:check || bash scripts/restart-extension-host.sh
```

---

### Fix 3.3: Automated Diagnostic Report

**File:** Create `scripts/diagnostic-report.sh`

```bash
#!/bin/bash
# Generate VS Code Extension Host diagnostic report

echo "=== VS Code Extension Host Diagnostic Report ===" > diagnostic-report.txt
echo "Generated: $(date)" >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "1. System Information" >> diagnostic-report.txt
echo "  Node Version: $(node --version)" >> diagnostic-report.txt
echo "  NPM Version: $(npm --version)" >> diagnostic-report.txt
echo "  OS: $(uname -a)" >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "2. Extension Host Status" >> diagnostic-report.txt
ps aux | grep -i "extensionHost" | grep -v grep >> diagnostic-report.txt 2>&1 || echo "  (no running processes)" >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "3. Lock File Status" >> diagnostic-report.txt
find ~/.vscode-remote/data/User/workspaceStorage -name "vscode.lock" -ls >> diagnostic-report.txt 2>&1 || echo "  (no lock files)" >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "4. Recent Extension Host Logs" >> diagnostic-report.txt
ls -lart ~/.vscode-remote/data/User/logs/ 2>/dev/null | tail -5 >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "5. Network Connectivity" >> diagnostic-report.txt
timeout 5 curl -I https://api.mcp.github.com 2>&1 >> diagnostic-report.txt || echo "  api.mcp.github.com: UNREACHABLE" >> diagnostic-report.txt
timeout 5 curl -I https://api.github.com 2>&1 >> diagnostic-report.txt || echo "  api.github.com: UNREACHABLE" >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "6. Memory Usage" >> diagnostic-report.txt
free -h >> diagnostic-report.txt
echo "" >> diagnostic-report.txt

echo "✓ Report generated: diagnostic-report.txt"
cat diagnostic-report.txt
```

---

## PHASE 3.4: Prevention Checklist

**Create:** `.devcontainer/maintenance.md`

```markdown
# VS Code Extension Host Maintenance Checklist

## Weekly Tasks
- [ ] Clear workspace storage locks: `find ~/.vscode-remote/data/User/workspaceStorage -mtime +7 -name vscode.lock -delete`
- [ ] Update extensions (manual): `code --extensions-dir ~/.vscode/extensions --install-extension <id> --force`
- [ ] Review extension host logs for patterns

## Monthly Tasks
- [ ] Update Node image version in devcontainer.json
- [ ] Run `npm update` to patch dependencies
- [ ] Test in fresh container rebuild
- [ ] Review and update devcontainer.json settings

## If Extension Host Keeps Crashing
1. Run: `npm run health:check`
2. If issues detected, run: `bash scripts/restart-extension-host.sh`
3. If problems persist, run: `bash scripts/diagnostic-report.sh`
4. Share report and file issue with details

## Emergency Recovery
```bash
# Nuclear option (clears all VS Code remote state)
rm -rf ~/.vscode-remote/
rm -rf ~/.local/share/code-server/
# Then: Remote-Containers: Rebuild Container
```
```

---

## Implementation Checklist

### PHASE 1 (Immediate - Do First)
- [ ] Fix 1.1: Clear lock files manually
- [ ] Fix 1.2: Update devcontainer.json with disabled settings
- [ ] Fix 1.3: Create `.vscode/settings.json` with timeout increases
- [ ] Restart VS Code container
- [ ] Verify no "unresponsive" messages for 5+ minutes

### PHASE 2 (Root Causes)
- [ ] Fix 2.1: Update Node image to 22+ (PREFERRED)
- [ ] Fix 2.2: Add lock file cleanup task
- [ ] Fix 2.3: Update MCP config with timeouts
- [ ] Fix 2.4: Disable experimental chat agents
- [ ] Rebuild container: `Remote-Containers: Rebuild Container`
- [ ] Monitor Extension Host logs for 15 minutes (no crashes expected)

### PHASE 3 (Hardening)
- [ ] Fix 3.1: Add health check script
- [ ] Fix 3.2: Create restart recovery script
- [ ] Fix 3.3: Create diagnostic report script
- [ ] Update package.json with health:check task
- [ ] Create maintenance checklist

---

## Success Metrics

| Metric | Before | After | Target |
|--------|--------|-------|--------|
| **Crashes per hour** | 6-12 | 0 | 0 |
| **Extension host uptime** | 5-10 min | 4+ hours | >24 hours |
| **Socket timeout frequency** | Every 5-10 min | Never | Never |
| **Extension load time** | 30-60s | 10-15s | <15s |
| **Chat responsiveness** | Intermittent | Consistent | Consistent |
| **Network error rate** | 20-30% | 0% | 0% |

---

## Troubleshooting Reference

### Symptom: Still getting "navigator" errors after updates
**Action:** 
1. Verify Node version: `node --version` (should be 22+)
2. Clear npm cache: `npm cache clean --force`
3. Reinstall dependencies: `npm install --force`
4. Rebuild container if still failing

### Symptom: Lock file errors persist
**Action:**
1. Kill all VS Code processes: `pkill -9 code || pkill -9 code-server`
2. Clear all locks: `find ~/.vscode-remote -name "vscode.lock" -delete`
3. Delete entire workspace storage: `rm -rf ~/.vscode-remote/data/User/workspaceStorage`
4. Restart VS Code from scratch

### Symptom: Socket keeps timing out
**Action:**
1. Check network: `curl -I https://api.github.com` (should succeed <5s)
2. Increase timeout in settings: `"remote.timeoutInSeconds": 120`
3. Disable auto-reconnect: `"remote.autoReconnect": false`
4. Restart connection manually: `Remote-Containers: Reopen in Container`

### Symptom: MCP context7 still failing
**Action:**
1. Leave `CONTEXT7_API_KEY` blank (will disable MCP)
2. Disable MCP in devcontainer: Add `"mcp.servers.io.github.upstash/context7.disabled": true`
3. MCP is optional - app works without it

---

## Expected Results After Implementation

✅ **Extension host stays up for 8+ hours**  
✅ **No socket timeouts or reconnections**  
✅ **Chat and code completion work reliably**  
✅ **No "navigator" or lock file errors**  
✅ **5-10x faster extension load time**  
✅ **Copilot is consistently available**  

---

**Next:** Implement PHASE 1 immediately, then proceed to PHASE 2-3
